-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 10, 2009 at 04:26 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `e-commerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `balance`
--

CREATE TABLE IF NOT EXISTS `balance` (
  `id` int(11) NOT NULL,
  `ab` varchar(50) NOT NULL,
  `rb` varchar(50) NOT NULL,
  `active` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `balance`
--

INSERT INTO `balance` (`id`, `ab`, `rb`, `active`) VALUES
(1, '481363.9', '0', '2013-09-01 12:00:00'),
(9, '54400', '0', '2013-10-13 10:19:23');

-- --------------------------------------------------------

--
-- Table structure for table `forgot`
--

CREATE TABLE IF NOT EXISTS `forgot` (
  `email` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `random` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `forgot`
--

INSERT INTO `forgot` (`email`, `random`) VALUES
('megpanth@gmail.com', '811920919');

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE IF NOT EXISTS `invoice` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `from` int(100) NOT NULL,
  `to` int(100) NOT NULL,
  `type` int(11) NOT NULL,
  `p_to` varchar(255) NOT NULL,
  `pricevalue` decimal(10,2) NOT NULL,
  `date` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `notified` varchar(255) NOT NULL DEFAULT 'no',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=405 ;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`id`, `from`, `to`, `type`, `p_to`, `pricevalue`, `date`, `code`, `notified`) VALUES
(401, 1, 9, 1, '1', '500.00', '1247196190', 'NULL', 'no'),
(402, 1, 0, 2, '24', '200.00', '1247198111', 'KIRAN-PAntha-IS', 'no'),
(403, 1, 9, 0, '0', '1000.00', '1247198700', 'NULL', 'no'),
(404, 9, 1, 0, '0', '100.00', '1247199837', 'NULL', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `invoice_underprocess`
--

CREATE TABLE IF NOT EXISTS `invoice_underprocess` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `from` int(100) NOT NULL,
  `to` int(100) NOT NULL,
  `type` int(11) NOT NULL,
  `p_to` varchar(255) NOT NULL,
  `pricevalue` decimal(10,2) NOT NULL,
  `date` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `notified` varchar(255) NOT NULL DEFAULT 'no',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `invoice_underprocess`
--

INSERT INTO `invoice_underprocess` (`id`, `from`, `to`, `type`, `p_to`, `pricevalue`, `date`, `code`, `notified`) VALUES
(18, 9, 9, 1, '3', '500.00', '1247196326', 'NULL', 'no'),
(19, 1, 1, 1, '1', '525.48', '1247197405', 'NULL', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `lastinfo`
--

CREATE TABLE IF NOT EXISTS `lastinfo` (
  `id` int(11) NOT NULL,
  `last` int(11) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `browser` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lastinfo`
--

INSERT INTO `lastinfo` (`id`, `last`, `ip`, `browser`) VALUES
(1, 1247198693, '127.0.0.1', 'Chrome browser'),
(9, 1247199815, '127.0.0.1', 'Chrome browser');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE IF NOT EXISTS `members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(65) NOT NULL DEFAULT '',
  `email` varchar(65) NOT NULL DEFAULT '',
  `organization` varchar(50) NOT NULL,
  `password1` varchar(50) NOT NULL,
  `password2` varchar(50) NOT NULL,
  `address` varchar(65) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `birthday` varchar(15) NOT NULL,
  `gender` varchar(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `name`, `email`, `organization`, `password1`, `password2`, `address`, `phone`, `birthday`, `gender`) VALUES
(9, 'Gaurav Panth', 'megpanth@gmail.com', 'Gpanthsoft', '7334a29c268411893225509d96447ea0', 'a36fb4e47ea23d3a87c6a6dbdff0c8b6', 'Millanchowk Nepal', '071541237', '28-May-1998', 'M'),
(1, 'Kiran Pantha', 'admin', 'Kiransoft Nepal', '21232f297a57a5a743894a0e4a801fc3', '21232f297a57a5a743894a0e4a801fc3', 'shankarnagar-5 Rupandehi Nepal', '071621283', '16-Jun-1996', 'M');

-- --------------------------------------------------------

--
-- Table structure for table `merchants`
--

CREATE TABLE IF NOT EXISTS `merchants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `company` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `uri` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `s_c` varchar(50) NOT NULL,
  `price` decimal(50,5) NOT NULL,
  `ifyes` varchar(500) NOT NULL,
  `ifno` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `merchants`
--

INSERT INTO `merchants` (`id`, `userid`, `name`, `company`, `uri`, `s_c`, `price`, `ifyes`, `ifno`) VALUES
(1, 1, 'English 2 Nepali', 'Kiransoft Nepal', 'e2n.kiranpantha.com.np', 'KIRANSOFTNEPAL', '525.47500', 'http://127.0.0.1/e2n/payment.php', 'http://127.0.0.1/e2n/payment.php'),
(2, 2, 'XYZ', 'XYZ Software', 'www.xyz.com', 'XYZSOFTINFO', '925.40000', 'http://127.0.0.1/online/pay.php', 'http://127.0.0.1/online/pay.php?false=true'),
(3, 9, 'Online School Software', 'Kiransoft Nepal', 'http://localhost', '15C253EBEB582BE', '500.00000', 'http://localhost/online/payment.php', 'http://localhost/online/admin.php');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(10) NOT NULL,
  `info` varchar(50) NOT NULL,
  `from` varchar(500) NOT NULL,
  `pricevalue` int(11) NOT NULL,
  `imgsrc` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `type`, `info`, `from`, `pricevalue`, `imgsrc`) VALUES
(20, 'rch', 'NTC recharge Card', 'Nepal Telecom', 1000, '620c66eebf2fb533370bf516062adfac_54e36c5ff5f6a1802925ca009f3ebb68.png'),
(21, 'rch', 'Ncell Recharge Card', 'Ncell', 100, '820d6548772c1c069656cac07a0a1782_358c850b3836ae02b1d8b319d86d435f.png'),
(22, 'rch', 'UTL Rechrge Card [Rs 100]', 'United Telecom', 110, '78faa68c359f3c35469f348a9e60da83_46123e470d3226911c48df4e9867b9db.png'),
(23, 'rch', 'Dish Home [Rs 500]', 'Dish Media Network Pvt. Ltd.', 520, '797e0c2f9b8381d6332aece010503781_19e901474bd32d47931f0219992ff889.png'),
(24, 'rch', 'NTC SKY Recharge Card', 'Nepal Telecom', 200, 'a097cbf965080b19d13343111219e2ce_a4bd4d2b1cc64abf1fffb8103da2b890.png');

-- --------------------------------------------------------

--
-- Table structure for table `product_code`
--

CREATE TABLE IF NOT EXISTS `product_code` (
  `id` int(11) NOT NULL,
  `code` char(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_code`
--

INSERT INTO `product_code` (`id`, `code`) VALUES
(20, 'fdsa'),
(20, 'fds'),
(20, 'fd'),
(20, 'fdsaaaaaaaa'),
(20, 'fdsaaaaaaaaa');

-- --------------------------------------------------------

--
-- Table structure for table `secure_merchant`
--

CREATE TABLE IF NOT EXISTS `secure_merchant` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `company` varchar(50) NOT NULL,
  `uri` varchar(500) NOT NULL,
  `s_c` varchar(50) NOT NULL,
  `price` int(11) NOT NULL,
  `ifyes` varchar(500) NOT NULL,
  `ifno` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `secure_merchant`
--


-- --------------------------------------------------------

--
-- Table structure for table `security_check`
--

CREATE TABLE IF NOT EXISTS `security_check` (
  `ip` varchar(15) NOT NULL,
  `code` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `security_check`
--

INSERT INTO `security_check` (`ip`, `code`) VALUES
('127.0.0.1', 'PQW1M21V$');

-- --------------------------------------------------------

--
-- Table structure for table `temp_members_db`
--

CREATE TABLE IF NOT EXISTS `temp_members_db` (
  `confirm_code` varchar(65) NOT NULL DEFAULT '',
  `name` varchar(65) NOT NULL DEFAULT '',
  `email` varchar(65) NOT NULL DEFAULT '',
  `organization` varchar(50) NOT NULL,
  `password1` varchar(50) NOT NULL,
  `password2` varchar(50) NOT NULL,
  `address` varchar(65) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `birthday` varchar(15) NOT NULL,
  `gender` varchar(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `temp_members_db`
--

